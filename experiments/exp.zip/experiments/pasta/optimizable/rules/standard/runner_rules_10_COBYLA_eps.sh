#!/bin/bash
#SBATCH --job-name=qr_r10
#SBATCH --ntasks=1
#SBATCH --mem=16gb
#SBATCH --partition=longrun
#SBATCH --output=qr_r10_COBYLA_eps.log

echo "Started at: "
date

for i in `seq 2 9`; do 
echo "instance $i"
time pasta qr_nqr_rules_10_$i.lp --query="qr" --optimize --epsilon=0.06 --threshold=0.7 --target=upper --verbose --method=COBYLA
done 

echo "Ended at: "
date
