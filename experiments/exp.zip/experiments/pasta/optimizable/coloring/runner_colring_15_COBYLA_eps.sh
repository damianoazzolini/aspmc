#!/bin/bash
#SBATCH --job-name=coloring15
#SBATCH --ntasks=1
#SBATCH --mem=16gb
#SBATCH --partition=longrun
#SBATCH --output=coloring_15_COBYLA_eps.log

echo "Started at: "
date

time pasta sm_gc_15_pf.lp --query="qr" --optimize --epsilon=0.06 --threshold=0.07 --target=upper --verbose --method=COBYLA

echo "Ended at: "
date
