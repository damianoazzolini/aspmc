# sbatch runner_colring_6_COBYLA_no_eps.sh
# sbatch runner_colring_6_COBYLA_eps.sh
# sbatch runner_colring_6_SLSQP_no_eps.sh
# sbatch runner_colring_6_SLSQP_eps.sh
sbatch runner_colring_7_COBYLA_no_eps.sh
sbatch runner_colring_7_COBYLA_eps.sh
sbatch runner_colring_7_SLSQP_no_eps.sh
sbatch runner_colring_7_SLSQP_eps.sh
sbatch runner_colring_8_COBYLA_no_eps.sh
sbatch runner_colring_8_COBYLA_eps.sh
sbatch runner_colring_8_SLSQP_no_eps.sh
sbatch runner_colring_8_SLSQP_eps.sh
sbatch runner_colring_9_COBYLA_no_eps.sh
sbatch runner_colring_9_COBYLA_eps.sh
sbatch runner_colring_9_SLSQP_no_eps.sh
sbatch runner_colring_9_SLSQP_eps.sh
sbatch runner_colring_10_COBYLA_no_eps.sh
sbatch runner_colring_10_COBYLA_eps.sh
sbatch runner_colring_10_SLSQP_no_eps.sh
sbatch runner_colring_10_SLSQP_eps.sh
sbatch runner_colring_11_COBYLA_no_eps.sh
sbatch runner_colring_11_COBYLA_eps.sh
sbatch runner_colring_11_SLSQP_no_eps.sh
sbatch runner_colring_11_SLSQP_eps.sh
sbatch runner_colring_12_COBYLA_no_eps.sh
sbatch runner_colring_12_COBYLA_eps.sh
sbatch runner_colring_12_SLSQP_no_eps.sh
sbatch runner_colring_12_SLSQP_eps.sh

# sbatch runner_colring_13_COBYLA_no_eps.sh
# sbatch runner_colring_13_COBYLA_eps.sh
# sbatch runner_colring_13_SLSQP_no_eps.sh
# sbatch runner_colring_13_SLSQP_eps.sh
# sbatch runner_colring_14_COBYLA_no_eps.sh
# sbatch runner_colring_14_COBYLA_eps.sh
# sbatch runner_colring_14_SLSQP_no_eps.sh
# sbatch runner_colring_14_SLSQP_eps.sh
# sbatch runner_colring_15_COBYLA_no_eps.sh
# sbatch runner_colring_15_COBYLA_eps.sh
# sbatch runner_colring_15_SLSQP_no_eps.sh
# sbatch runner_colring_15_SLSQP_eps.sh
# sbatch runner_colring_16_COBYLA_no_eps.sh
# sbatch runner_colring_16_COBYLA_eps.sh
# sbatch runner_colring_16_SLSQP_no_eps.sh
# sbatch runner_colring_16_SLSQP_eps.sh
# sbatch runner_colring_17_COBYLA_no_eps.sh
# sbatch runner_colring_17_COBYLA_eps.sh
# sbatch runner_colring_17_SLSQP_no_eps.sh
# sbatch runner_colring_17_SLSQP_eps.sh
# sbatch runner_colring_18_COBYLA_no_eps.sh
# sbatch runner_colring_18_COBYLA_eps.sh
# sbatch runner_colring_18_SLSQP_no_eps.sh
# sbatch runner_colring_18_SLSQP_eps.sh
# sbatch runner_colring_19_COBYLA_no_eps.sh
# sbatch runner_colring_19_COBYLA_eps.sh
# sbatch runner_colring_19_SLSQP_no_eps.sh
# sbatch runner_colring_19_SLSQP_eps.sh
# sbatch runner_colring_20_COBYLA_no_eps.sh
# sbatch runner_colring_20_COBYLA_eps.sh
# sbatch runner_colring_20_SLSQP_no_eps.sh
# sbatch runner_colring_20_SLSQP_eps.sh
