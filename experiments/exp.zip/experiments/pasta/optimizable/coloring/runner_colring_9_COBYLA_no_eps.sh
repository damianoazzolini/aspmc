#!/bin/bash
#SBATCH --job-name=coloring9
#SBATCH --ntasks=1
#SBATCH --mem=16gb
#SBATCH --partition=longrun
#SBATCH --output=coloring_9_COBYLA_no_eps.log

echo "Started at: "
date

time pasta sm_gc_9_pf.lp --query="qr" --optimize  --threshold=0.07 --target=upper --verbose --method=COBYLA

echo "Ended at: "
date
