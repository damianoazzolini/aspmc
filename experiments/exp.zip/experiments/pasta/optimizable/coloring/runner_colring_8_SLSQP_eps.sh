#!/bin/bash
#SBATCH --job-name=coloring8
#SBATCH --ntasks=1
#SBATCH --mem=16gb
#SBATCH --partition=longrun
#SBATCH --output=coloring_8_SLSQP_eps.log

echo "Started at: "
date

time pasta sm_gc_8_pf.lp --query="qr" --optimize --epsilon=0.06 --threshold=0.07 --target=upper --verbose --method=SLSQP

echo "Ended at: "
date
