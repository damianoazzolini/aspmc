#!/bin/bash
#SBATCH --job-name=smoke5
#SBATCH --ntasks=1
#SBATCH --mem=16gb
#SBATCH --partition=longrun
#SBATCH --output=smoke_5_SLSQP_no_eps.log

echo "Started at: "
date

time pasta t5.lp --query="qr" --optimize  --threshold=0.01 --target=upper --verbose --method=SLSQP

echo "Ended at: "
date
