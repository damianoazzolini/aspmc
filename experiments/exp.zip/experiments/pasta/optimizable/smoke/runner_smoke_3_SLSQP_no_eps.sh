#!/bin/bash
#SBATCH --job-name=smoke3
#SBATCH --ntasks=1
#SBATCH --mem=16gb
#SBATCH --partition=longrun
#SBATCH --output=smoke_3_SLSQP_no_eps.log

echo "Started at: "
date

time pasta t3.lp --query="qr" --optimize  --threshold=0.01 --target=upper --verbose --method=SLSQP

echo "Ended at: "
date
