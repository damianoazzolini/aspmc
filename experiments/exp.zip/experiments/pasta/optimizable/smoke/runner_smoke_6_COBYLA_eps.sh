#!/bin/bash
#SBATCH --job-name=smoke6
#SBATCH --ntasks=1
#SBATCH --mem=16gb
#SBATCH --partition=longrun
#SBATCH --output=smoke_6_COBYLA_eps.log

echo "Started at: "
date

time pasta t6.lp --query="qr" --optimize --epsilon=0.06 --threshold=0.01 --target=upper --verbose --method=COBYLA

echo "Ended at: "
date
