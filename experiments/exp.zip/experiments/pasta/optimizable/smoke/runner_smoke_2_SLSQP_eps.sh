#!/bin/bash
#SBATCH --job-name=smoke2
#SBATCH --ntasks=1
#SBATCH --mem=16gb
#SBATCH --partition=longrun
#SBATCH --output=smoke_2_SLSQP_eps.log

echo "Started at: "
date

time pasta t2.lp --query="qr" --optimize --epsilon=0.06 --threshold=0.01 --target=upper --verbose --method=SLSQP

echo "Ended at: "
date
