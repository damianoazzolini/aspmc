#!/bin/bash
#SBATCH --job-name=smoke1
#SBATCH --ntasks=1
#SBATCH --mem=16gb
#SBATCH --partition=longrun
#SBATCH --output=smoke_1_COBYLA_no_eps.log

echo "Started at: "
date

time pasta t1.lp --query="qr" --optimize  --threshold=0.01 --target=upper --verbose --method=COBYLA

echo "Ended at: "
date
