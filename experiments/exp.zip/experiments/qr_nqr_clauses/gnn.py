for i in range(0,25):
    print(f"0.03::a{i}.")
    
for i in range(0,25):
    print(f"qr:- a{i}.")