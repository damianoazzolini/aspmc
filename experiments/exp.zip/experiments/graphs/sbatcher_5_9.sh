# sbatch run_5_COBYLA_noc.sh
# sbatch run_5_COBYLA.sh
sbatch run_5_SLSQP_noc.sh
sbatch run_5_SLSQP.sh
# sbatch run_6_COBYLA_noc.sh
# sbatch run_6_COBYLA.sh
sbatch run_6_SLSQP_noc.sh
sbatch run_6_SLSQP.sh
# sbatch run_7_COBYLA_noc.sh
# sbatch run_7_COBYLA.sh
sbatch run_7_SLSQP_noc.sh
sbatch run_7_SLSQP.sh
# sbatch run_8_COBYLA_noc.sh
# sbatch run_8_COBYLA.sh
sbatch run_8_SLSQP_noc.sh
sbatch run_8_SLSQP.sh
# sbatch run_9_COBYLA_noc.sh
# sbatch run_9_COBYLA.sh
sbatch run_9_SLSQP_noc.sh
sbatch run_9_SLSQP.sh
