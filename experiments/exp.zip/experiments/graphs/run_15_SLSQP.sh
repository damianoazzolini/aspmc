#!/bin/bash
#SBATCH --job-name=g_15_s
#SBATCH --ntasks=1
#SBATCH --mem=16gb
#SBATCH --partition=longrun
#SBATCH --output=graph_15_s.log

echo "Started at: " 
date

echo "Instance 2"
time python runner_with_pair_constr.py inst_15.lp SLSQP "edge(1,2)" "edge(1,3)"
echo "Instance 3"
time python runner_with_pair_constr.py inst_15.lp SLSQP "edge(1,2)" "edge(1,3)" "edge(2,4)"
echo "Instance 4"
time python runner_with_pair_constr.py inst_15.lp SLSQP "edge(1,2)" "edge(1,3)" "edge(2,4)" "edge(3,5)"
echo "Instance 5"
time python runner_with_pair_constr.py inst_15.lp SLSQP "edge(1,2)" "edge(1,3)" "edge(2,4)" "edge(3,5)" "edge(4,6)"
echo "Instance 6"
time python runner_with_pair_constr.py inst_15.lp SLSQP "edge(1,2)" "edge(1,3)" "edge(2,4)" "edge(3,5)" "edge(4,6)" "edge(5,6)"
echo "Instance 7"
time python runner_with_pair_constr.py inst_15.lp SLSQP "edge(1,2)" "edge(1,3)" "edge(2,4)" "edge(3,5)" "edge(4,6)" "edge(5,6)" "edge(6,7)"
echo "Instance 8"
time python runner_with_pair_constr.py inst_15.lp SLSQP "edge(1,2)" "edge(1,3)" "edge(2,4)" "edge(3,5)" "edge(4,6)" "edge(5,6)" "edge(6,7)" "edge(6,8)"
echo "Instance 9"
time python runner_with_pair_constr.py inst_15.lp SLSQP "edge(1,2)" "edge(1,3)" "edge(2,4)" "edge(3,5)" "edge(4,6)" "edge(5,6)" "edge(6,7)" "edge(6,8)" "edge(7,9)"
echo "Instance 10"
time python runner_with_pair_constr.py inst_15.lp SLSQP "edge(1,2)" "edge(1,3)" "edge(2,4)" "edge(3,5)" "edge(4,6)" "edge(5,6)" "edge(6,7)" "edge(6,8)" "edge(7,9)" "edge(8,9)"
echo "Instance 11"
time python runner_with_pair_constr.py inst_15.lp SLSQP "edge(1,2)" "edge(1,3)" "edge(2,4)" "edge(3,5)" "edge(4,6)" "edge(5,6)" "edge(6,7)" "edge(6,8)" "edge(7,9)" "edge(8,9)" "edge(9,10)"
echo "Instance 12"
time python runner_with_pair_constr.py inst_15.lp SLSQP "edge(1,2)" "edge(1,3)" "edge(2,4)" "edge(3,5)" "edge(4,6)" "edge(5,6)" "edge(6,7)" "edge(6,8)" "edge(7,9)" "edge(8,9)" "edge(9,10)" "edge(9,11)"
echo "Instance 13"
time python runner_with_pair_constr.py inst_15.lp SLSQP "edge(1,2)" "edge(1,3)" "edge(2,4)" "edge(3,5)" "edge(4,6)" "edge(5,6)" "edge(6,7)" "edge(6,8)" "edge(7,9)" "edge(8,9)" "edge(9,10)" "edge(9,11)" "edge(10,12)"
echo "Instance 14"
time python runner_with_pair_constr.py inst_15.lp SLSQP "edge(1,2)" "edge(1,3)" "edge(2,4)" "edge(3,5)" "edge(4,6)" "edge(5,6)" "edge(6,7)" "edge(6,8)" "edge(7,9)" "edge(8,9)" "edge(9,10)" "edge(9,11)" "edge(10,12)" "edge(11,13)"
echo "Instance 15"
time python runner_with_pair_constr.py inst_15.lp SLSQP "edge(1,2)" "edge(1,3)" "edge(2,4)" "edge(3,5)" "edge(4,6)" "edge(5,6)" "edge(6,7)" "edge(6,8)" "edge(7,9)" "edge(8,9)" "edge(9,10)" "edge(9,11)" "edge(10,12)" "edge(11,13)" "edge(12,13)"

echo "Ended at: " 
date
