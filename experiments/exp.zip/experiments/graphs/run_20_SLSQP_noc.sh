#!/bin/bash
#SBATCH --job-name=g_20_noc_s
#SBATCH --ntasks=1
#SBATCH --mem=16gb
#SBATCH --partition=longrun
#SBATCH --output=graph_20_no_constr_s.log

echo "Started at: " 
date

echo "Instance 2"
time python runner_without_pair_constr.py inst_20.lp SLSQP "edge(1,2)" "edge(1,3)"
echo "Instance 3"
time python runner_without_pair_constr.py inst_20.lp SLSQP "edge(1,2)" "edge(1,3)" "edge(2,4)"
echo "Instance 4"
time python runner_without_pair_constr.py inst_20.lp SLSQP "edge(1,2)" "edge(1,3)" "edge(2,4)" "edge(3,5)"
echo "Instance 5"
time python runner_without_pair_constr.py inst_20.lp SLSQP "edge(1,2)" "edge(1,3)" "edge(2,4)" "edge(3,5)" "edge(4,6)"
echo "Instance 6"
time python runner_without_pair_constr.py inst_20.lp SLSQP "edge(1,2)" "edge(1,3)" "edge(2,4)" "edge(3,5)" "edge(4,6)" "edge(5,6)"
echo "Instance 7"
time python runner_without_pair_constr.py inst_20.lp SLSQP "edge(1,2)" "edge(1,3)" "edge(2,4)" "edge(3,5)" "edge(4,6)" "edge(5,6)" "edge(6,7)"
echo "Instance 8"
time python runner_without_pair_constr.py inst_20.lp SLSQP "edge(1,2)" "edge(1,3)" "edge(2,4)" "edge(3,5)" "edge(4,6)" "edge(5,6)" "edge(6,7)" "edge(6,8)"
echo "Instance 9"
time python runner_without_pair_constr.py inst_20.lp SLSQP "edge(1,2)" "edge(1,3)" "edge(2,4)" "edge(3,5)" "edge(4,6)" "edge(5,6)" "edge(6,7)" "edge(6,8)" "edge(7,9)"
echo "Instance 10"
time python runner_without_pair_constr.py inst_20.lp SLSQP "edge(1,2)" "edge(1,3)" "edge(2,4)" "edge(3,5)" "edge(4,6)" "edge(5,6)" "edge(6,7)" "edge(6,8)" "edge(7,9)" "edge(8,9)"
echo "Instance 11"
time python runner_without_pair_constr.py inst_20.lp SLSQP "edge(1,2)" "edge(1,3)" "edge(2,4)" "edge(3,5)" "edge(4,6)" "edge(5,6)" "edge(6,7)" "edge(6,8)" "edge(7,9)" "edge(8,9)" "edge(9,10)"
echo "Instance 12"
time python runner_without_pair_constr.py inst_20.lp SLSQP "edge(1,2)" "edge(1,3)" "edge(2,4)" "edge(3,5)" "edge(4,6)" "edge(5,6)" "edge(6,7)" "edge(6,8)" "edge(7,9)" "edge(8,9)" "edge(9,10)" "edge(9,11)"
echo "Instance 13"
time python runner_without_pair_constr.py inst_20.lp SLSQP "edge(1,2)" "edge(1,3)" "edge(2,4)" "edge(3,5)" "edge(4,6)" "edge(5,6)" "edge(6,7)" "edge(6,8)" "edge(7,9)" "edge(8,9)" "edge(9,10)" "edge(9,11)" "edge(10,12)"
echo "Instance 14"
time python runner_without_pair_constr.py inst_20.lp SLSQP "edge(1,2)" "edge(1,3)" "edge(2,4)" "edge(3,5)" "edge(4,6)" "edge(5,6)" "edge(6,7)" "edge(6,8)" "edge(7,9)" "edge(8,9)" "edge(9,10)" "edge(9,11)" "edge(10,12)" "edge(11,13)"
echo "Instance 15"
time python runner_without_pair_constr.py inst_20.lp SLSQP "edge(1,2)" "edge(1,3)" "edge(2,4)" "edge(3,5)" "edge(4,6)" "edge(5,6)" "edge(6,7)" "edge(6,8)" "edge(7,9)" "edge(8,9)" "edge(9,10)" "edge(9,11)" "edge(10,12)" "edge(11,13)" "edge(12,13)"
echo "Instance 16"
time python runner_without_pair_constr.py inst_20.lp SLSQP "edge(1,2)" "edge(1,3)" "edge(2,4)" "edge(3,5)" "edge(4,6)" "edge(5,6)" "edge(6,7)" "edge(6,8)" "edge(7,9)" "edge(8,9)" "edge(9,10)" "edge(9,11)" "edge(10,12)" "edge(11,13)" "edge(12,13)" "edge(13,14)"
echo "Instance 17"
time python runner_without_pair_constr.py inst_20.lp SLSQP "edge(1,2)" "edge(1,3)" "edge(2,4)" "edge(3,5)" "edge(4,6)" "edge(5,6)" "edge(6,7)" "edge(6,8)" "edge(7,9)" "edge(8,9)" "edge(9,10)" "edge(9,11)" "edge(10,12)" "edge(11,13)" "edge(12,13)" "edge(13,14)" "edge(14,17)"
echo "Instance 18"
time python runner_without_pair_constr.py inst_20.lp SLSQP "edge(1,2)" "edge(1,3)" "edge(2,4)" "edge(3,5)" "edge(4,6)" "edge(5,6)" "edge(6,7)" "edge(6,8)" "edge(7,9)" "edge(8,9)" "edge(9,10)" "edge(9,11)" "edge(10,12)" "edge(11,13)" "edge(12,13)" "edge(13,14)" "edge(14,17)" "edge(13,15)"
echo "Instance 19"
time python runner_without_pair_constr.py inst_20.lp SLSQP "edge(1,2)" "edge(1,3)" "edge(2,4)" "edge(3,5)" "edge(4,6)" "edge(5,6)" "edge(6,7)" "edge(6,8)" "edge(7,9)" "edge(8,9)" "edge(9,10)" "edge(9,11)" "edge(10,12)" "edge(11,13)" "edge(12,13)" "edge(13,14)" "edge(14,17)" "edge(13,15)" "edge(15,16)"
echo "Instance 20"
time python runner_without_pair_constr.py inst_20.lp SLSQP "edge(1,2)" "edge(1,3)" "edge(2,4)" "edge(3,5)" "edge(4,6)" "edge(5,6)" "edge(6,7)" "edge(6,8)" "edge(7,9)" "edge(8,9)" "edge(9,10)" "edge(9,11)" "edge(10,12)" "edge(11,13)" "edge(12,13)" "edge(13,14)" "edge(14,17)" "edge(13,15)" "edge(15,16)" "edge(17,16)"

echo "Ended at: " 
date
