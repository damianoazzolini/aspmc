#!/bin/bash
#SBATCH --job-name=g_8_c
#SBATCH --ntasks=1
#SBATCH --mem=16gb
#SBATCH --partition=longrun
#SBATCH --output=graph_8_c.log

echo "Started at: " 
date

echo "Instance 2"
time python runner_with_pair_constr.py inst_8.lp COBYLA "edge(1,2)" "edge(1,3)"
echo "Instance 3"
time python runner_with_pair_constr.py inst_8.lp COBYLA "edge(1,2)" "edge(1,3)" "edge(2,4)"
echo "Instance 4"
time python runner_with_pair_constr.py inst_8.lp COBYLA "edge(1,2)" "edge(1,3)" "edge(2,4)" "edge(3,5)"
echo "Instance 5"
time python runner_with_pair_constr.py inst_8.lp COBYLA "edge(1,2)" "edge(1,3)" "edge(2,4)" "edge(3,5)" "edge(4,6)"
echo "Instance 6"
time python runner_with_pair_constr.py inst_8.lp COBYLA "edge(1,2)" "edge(1,3)" "edge(2,4)" "edge(3,5)" "edge(4,6)" "edge(5,6)"
echo "Instance 7"
time python runner_with_pair_constr.py inst_8.lp COBYLA "edge(1,2)" "edge(1,3)" "edge(2,4)" "edge(3,5)" "edge(4,6)" "edge(5,6)" "edge(6,7)"
echo "Instance 8"
time python runner_with_pair_constr.py inst_8.lp COBYLA "edge(1,2)" "edge(1,3)" "edge(2,4)" "edge(3,5)" "edge(4,6)" "edge(5,6)" "edge(6,7)" "edge(6,8)"

echo "Ended at: " 
date
