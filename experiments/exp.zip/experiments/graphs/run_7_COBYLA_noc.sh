#!/bin/bash
#SBATCH --job-name=g_7_noc_c
#SBATCH --ntasks=1
#SBATCH --mem=16gb
#SBATCH --partition=longrun
#SBATCH --output=graph_7_no_constr_c.log

echo "Started at: " 
date

echo "Instance 2"
time python runner_without_pair_constr.py inst_7.lp COBYLA "edge(1,2)" "edge(1,3)"
echo "Instance 3"
time python runner_without_pair_constr.py inst_7.lp COBYLA "edge(1,2)" "edge(1,3)" "edge(2,4)"
echo "Instance 4"
time python runner_without_pair_constr.py inst_7.lp COBYLA "edge(1,2)" "edge(1,3)" "edge(2,4)" "edge(3,5)"
echo "Instance 5"
time python runner_without_pair_constr.py inst_7.lp COBYLA "edge(1,2)" "edge(1,3)" "edge(2,4)" "edge(3,5)" "edge(4,6)"
echo "Instance 6"
time python runner_without_pair_constr.py inst_7.lp COBYLA "edge(1,2)" "edge(1,3)" "edge(2,4)" "edge(3,5)" "edge(4,6)" "edge(5,6)"
echo "Instance 7"
time python runner_without_pair_constr.py inst_7.lp COBYLA "edge(1,2)" "edge(1,3)" "edge(2,4)" "edge(3,5)" "edge(4,6)" "edge(5,6)" "edge(6,7)"

echo "Ended at: " 
date
