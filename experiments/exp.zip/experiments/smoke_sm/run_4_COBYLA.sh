#!/bin/bash
#SBATCH --job-name=sm_4_c
#SBATCH --ntasks=1
#SBATCH --mem=16gb
#SBATCH --partition=longrun
#SBATCH --output=sm_4_c.log

echo "Started at: " 
date

echo "Instance 4"
time python runner_with_pair_constr.py t4.lp COBYLA "influences(1,2)" "influences(2,1)" "influences(2,3)"

echo "Ended at: " 
date
