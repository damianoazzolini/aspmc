#!/bin/bash
#SBATCH --job-name=sm_6_noc_s
#SBATCH --ntasks=1
#SBATCH --mem=16gb
#SBATCH --partition=longrun
#SBATCH --output=sm_6_no_constr_s.log

echo "Started at: " 
date

echo "Instance 6"
time python runner_without_pair_constr.py t6.lp SLSQP "influences(1,2)" "influences(2,1)" "influences(2,3)" "influences(3,4)" "influences(4,1)"

echo "Ended at: " 
date
