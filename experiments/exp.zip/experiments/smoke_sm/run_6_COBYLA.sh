#!/bin/bash
#SBATCH --job-name=sm_6_c
#SBATCH --ntasks=1
#SBATCH --mem=16gb
#SBATCH --partition=longrun
#SBATCH --output=sm_6_c.log

echo "Started at: " 
date

echo "Instance 6"
time python runner_with_pair_constr.py t6.lp COBYLA "influences(1,2)" "influences(2,1)" "influences(2,3)" "influences(3,4)" "influences(4,1)"

echo "Ended at: " 
date
