#!/bin/bash
#SBATCH --job-name=sm_5_s
#SBATCH --ntasks=1
#SBATCH --mem=16gb
#SBATCH --partition=longrun
#SBATCH --output=sm_5_s.log

echo "Started at: " 
date

echo "Instance 5"
time python runner_with_pair_constr.py t5.lp SLSQP "influences(1,2)" "influences(2,1)" "influences(2,3)" "influences(3,4)"

echo "Ended at: " 
date
