#!/bin/bash
#SBATCH --job-name=qr_c_cn20_noc
#SBATCH --ntasks=1
#SBATCH --mem=16gb
#SBATCH --partition=longrun
#SBATCH --output=qr_nqr_clauses_not_COBYLA_20_no_constr.log

echo "Started at: " 
date

echo "Instance: 2"
time python runner_without_pair_constr.py t1_20_pf.lp COBYLA "a0" "a1"
echo "Instance: 3"
time python runner_without_pair_constr.py t1_20_pf.lp COBYLA "a0" "a1" "a2"
echo "Instance: 4"
time python runner_without_pair_constr.py t1_20_pf.lp COBYLA "a0" "a1" "a2" "a3"
echo "Instance: 5"
time python runner_without_pair_constr.py t1_20_pf.lp COBYLA "a0" "a1" "a2" "a3" "a4"
echo "Instance: 6"
time python runner_without_pair_constr.py t1_20_pf.lp COBYLA "a0" "a1" "a2" "a3" "a4" "a5"
echo "Instance: 7"
time python runner_without_pair_constr.py t1_20_pf.lp COBYLA "a0" "a1" "a2" "a3" "a4" "a5" "a6"
echo "Instance: 8"
time python runner_without_pair_constr.py t1_20_pf.lp COBYLA "a0" "a1" "a2" "a3" "a4" "a5" "a6" "a7"
echo "Instance: 9"
time python runner_without_pair_constr.py t1_20_pf.lp COBYLA "a0" "a1" "a2" "a3" "a4" "a5" "a6" "a7" "a8"
echo "Instance: 10"
time python runner_without_pair_constr.py t1_20_pf.lp COBYLA "a0" "a1" "a2" "a3" "a4" "a5" "a6" "a7" "a8" "a9"
echo "Instance: 11"
time python runner_without_pair_constr.py t1_20_pf.lp COBYLA "a0" "a1" "a2" "a3" "a4" "a5" "a6" "a7" "a8" "a9" "a10"
echo "Instance: 12"
time python runner_without_pair_constr.py t1_20_pf.lp COBYLA "a0" "a1" "a2" "a3" "a4" "a5" "a6" "a7" "a8" "a9" "a10" "a11"
echo "Instance: 13"
time python runner_without_pair_constr.py t1_20_pf.lp COBYLA "a0" "a1" "a2" "a3" "a4" "a5" "a6" "a7" "a8" "a9" "a10" "a11" "a12"
echo "Instance: 14"
time python runner_without_pair_constr.py t1_20_pf.lp COBYLA "a0" "a1" "a2" "a3" "a4" "a5" "a6" "a7" "a8" "a9" "a10" "a11" "a12" "a13"
echo "Instance: 15"
time python runner_without_pair_constr.py t1_20_pf.lp COBYLA "a0" "a1" "a2" "a3" "a4" "a5" "a6" "a7" "a8" "a9" "a10" "a11" "a12" "a13" "a14"
echo "Instance: 16"
time python runner_without_pair_constr.py t1_20_pf.lp COBYLA "a0" "a1" "a2" "a3" "a4" "a5" "a6" "a7" "a8" "a9" "a10" "a11" "a12" "a13" "a14" "a15"
echo "Instance: 17"
time python runner_without_pair_constr.py t1_20_pf.lp COBYLA "a0" "a1" "a2" "a3" "a4" "a5" "a6" "a7" "a8" "a9" "a10" "a11" "a12" "a13" "a14" "a15" "a16"
echo "Instance: 18"
time python runner_without_pair_constr.py t1_20_pf.lp COBYLA "a0" "a1" "a2" "a3" "a4" "a5" "a6" "a7" "a8" "a9" "a10" "a11" "a12" "a13" "a14" "a15" "a16" "a17"
echo "Instance: 19"
time python runner_without_pair_constr.py t1_20_pf.lp COBYLA "a0" "a1" "a2" "a3" "a4" "a5" "a6" "a7" "a8" "a9" "a10" "a11" "a12" "a13" "a14" "a15" "a16" "a17" "a18"
echo "Instance: 20"
time python runner_without_pair_constr.py t1_20_pf.lp COBYLA "a0" "a1" "a2" "a3" "a4" "a5" "a6" "a7" "a8" "a9" "a10" "a11" "a12" "a13" "a14" "a15" "a16" "a17" "a18" "a19"

echo "Ended at: " 
date
