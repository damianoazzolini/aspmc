# sbatch run_10_COBYLA_noc.sh
# sbatch run_10_COBYLA.sh
# sbatch run_10_SLSQP_noc.sh
# sbatch run_10_SLSQP.sh
# sbatch run_15_COBYLA_noc.sh
# sbatch run_15_COBYLA.sh
# sbatch run_15_SLSQP_noc.sh
# sbatch run_15_SLSQP.sh
# sbatch run_20_COBYLA_noc.sh
# sbatch run_20_COBYLA.sh
# sbatch run_20_SLSQP_noc.sh
# sbatch run_20_SLSQP.sh
# sbatch run_25_COBYLA_noc.sh
# sbatch run_25_COBYLA.sh
# sbatch run_25_SLSQP_noc.sh
# sbatch run_25_SLSQP.sh
sbatch run_30_COBYLA_noc.sh
sbatch run_30_COBYLA.sh
sbatch run_30_SLSQP_noc.sh
sbatch run_30_SLSQP.sh