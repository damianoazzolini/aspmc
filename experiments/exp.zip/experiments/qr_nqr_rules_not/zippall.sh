python results_formatter.py
sleep 1
echo "Zipping"
zip res_qr_nqr_rules.zip *.cleaned