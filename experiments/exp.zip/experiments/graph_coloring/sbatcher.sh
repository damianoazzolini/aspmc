# sbatch run_6_COBYLA_noc.sh
# sbatch run_6_COBYLA.sh
sbatch run_6_SLSQP_noc.sh
sbatch run_6_SLSQP.sh
# sbatch run_7_COBYLA_noc.sh
# sbatch run_7_COBYLA.sh
sbatch run_7_SLSQP_noc.sh
sbatch run_7_SLSQP.sh
# sbatch run_8_COBYLA_noc.sh
# sbatch run_8_COBYLA.sh
sbatch run_8_SLSQP_noc.sh
sbatch run_8_SLSQP.sh
# sbatch run_9_COBYLA_noc.sh
# sbatch run_9_COBYLA.sh
sbatch run_9_SLSQP_noc.sh
sbatch run_9_SLSQP.sh
# sbatch run_10_COBYLA_noc.sh
# sbatch run_10_COBYLA.sh
sbatch run_10_SLSQP_noc.sh
sbatch run_10_SLSQP.sh
# sbatch run_11_COBYLA_noc.sh
# sbatch run_11_COBYLA.sh
sbatch run_11_SLSQP_noc.sh
sbatch run_11_SLSQP.sh
# sbatch run_12_COBYLA_noc.sh
# sbatch run_12_COBYLA.sh
sbatch run_12_SLSQP_noc.sh
sbatch run_12_SLSQP.sh

# sbatch run_13_COBYLA_noc.sh
# sbatch run_13_COBYLA.sh
sbatch run_13_SLSQP_noc.sh
sbatch run_13_SLSQP.sh
# sbatch run_14_COBYLA_noc.sh
# sbatch run_14_COBYLA.sh
sbatch run_14_SLSQP_noc.sh
sbatch run_14_SLSQP.sh
# sbatch run_15_COBYLA_noc.sh
# sbatch run_15_COBYLA.sh
sbatch run_15_SLSQP_noc.sh
sbatch run_15_SLSQP.sh
# sbatch run_16_COBYLA_noc.sh
# sbatch run_16_COBYLA.sh
sbatch run_16_SLSQP_noc.sh
sbatch run_16_SLSQP.sh

# sbatch run_17_COBYLA_noc.sh
# sbatch run_17_COBYLA.sh
# sbatch run_17_SLSQP_noc.sh
# sbatch run_17_SLSQP.sh
# sbatch run_18_COBYLA_noc.sh
# sbatch run_18_COBYLA.sh
# sbatch run_18_SLSQP_noc.sh
# sbatch run_18_SLSQP.sh
# sbatch run_19_COBYLA_noc.sh
# sbatch run_19_COBYLA.sh
# sbatch run_19_SLSQP_noc.sh
# sbatch run_19_SLSQP.sh
# sbatch run_20_COBYLA_noc.sh
# sbatch run_20_COBYLA.sh
# sbatch run_20_SLSQP_noc.sh
# sbatch run_20_SLSQP.sh
