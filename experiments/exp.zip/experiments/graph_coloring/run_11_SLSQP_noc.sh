#!/bin/bash
#SBATCH --job-name=coloring_11_noc_s
#SBATCH --ntasks=1
#SBATCH --mem=16gb
#SBATCH --partition=longrun
#SBATCH --output=sm_11_no_constr_s.log

echo "Started at: " 
date

echo "Instance 11"
time python runner_without_pair_constr.py sm_gc_11_pf.lp SLSQP "edge(1,2)" "edge(1,3)" "edge(2,5)" "edge(2,6)" "edge(3,4)" "edge(4,5)" "edge(5,6)" "edge(3,10)" "edge(6,11)" "edge(2,11)" "edge(6,10)" "edge(2,8)" "edge(1,5)"

echo "Ended at: " 
date
