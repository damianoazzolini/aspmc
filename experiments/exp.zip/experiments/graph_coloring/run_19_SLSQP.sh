#!/bin/bash
#SBATCH --job-name=coloring_19_s
#SBATCH --ntasks=1
#SBATCH --mem=16gb
#SBATCH --partition=longrun
#SBATCH --output=sm_19_s.log

echo "Started at: " 
date

echo "Instance 19"
time python runner_with_pair_constr.py sm_gc_19_pf.lp SLSQP "edge(1,2)" "edge(1,3)" "edge(2,5)" "edge(2,6)" "edge(3,4)" "edge(4,5)" "edge(5,6)" "edge(7,10)" "edge(5,10)" "edge(3,7)" "edge(13,18)" "edge(15,18)" "edge(14,16)" "edge(1,14)" "edge(3,17)" "edge(1,15)" "edge(13,16)" "edge(4,11)" "edge(8,17)" "edge(7,19)" "edge(11,17)"

echo "Ended at: " 
date
