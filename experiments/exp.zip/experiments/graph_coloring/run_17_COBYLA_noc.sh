#!/bin/bash
#SBATCH --job-name=coloring_17_noc_c
#SBATCH --ntasks=1
#SBATCH --mem=16gb
#SBATCH --partition=longrun
#SBATCH --output=sm_17_no_constr_c.log

echo "Started at: " 
date

echo "Instance 17"
time python runner_without_pair_constr.py sm_gc_17_pf.lp COBYLA "edge(1,2)" "edge(1,3)" "edge(2,5)" "edge(2,6)" "edge(3,4)" "edge(4,5)" "edge(5,6)" "edge(8,9)" "edge(2,14)" "edge(6,12)" "edge(2,9)" "edge(5,15)" "edge(2,17)" "edge(5,10)" "edge(11,12)" "edge(6,8)" "edge(1,8)" "edge(7,13)" "edge(3,10)"

echo "Ended at: " 
date
