#!/bin/bash
#SBATCH --job-name=coloring_18_s
#SBATCH --ntasks=1
#SBATCH --mem=16gb
#SBATCH --partition=longrun
#SBATCH --output=sm_18_s.log

echo "Started at: " 
date

echo "Instance 18"
time python runner_with_pair_constr.py sm_gc_18_pf.lp SLSQP "edge(1,2)" "edge(1,3)" "edge(2,5)" "edge(2,6)" "edge(3,4)" "edge(4,5)" "edge(5,6)" "edge(2,12)" "edge(8,10)" "edge(14,16)" "edge(3,13)" "edge(6,9)" "edge(8,11)" "edge(10,18)" "edge(14,15)" "edge(8,17)" "edge(4,17)" "edge(5,13)" "edge(1,12)" "edge(1,15)"

echo "Ended at: " 
date
