#!/bin/bash
#SBATCH --job-name=coloring_9_c
#SBATCH --ntasks=1
#SBATCH --mem=16gb
#SBATCH --partition=longrun
#SBATCH --output=sm_9_c.log

echo "Started at: " 
date

echo "Instance 9"
time python runner_with_pair_constr.py sm_gc_9_pf.lp COBYLA "edge(1,2)" "edge(1,3)" "edge(2,5)" "edge(2,6)" "edge(3,4)" "edge(4,5)" "edge(5,6)" "edge(3,7)" "edge(4,9)" "edge(3,5)" "edge(7,9)"

echo "Ended at: " 
date
