#!/bin/bash
#SBATCH --job-name=coloring_20_noc_s
#SBATCH --ntasks=1
#SBATCH --mem=16gb
#SBATCH --partition=longrun
#SBATCH --output=sm_20_no_constr_s.log

echo "Started at: " 
date

echo "Instance 20"
time python runner_without_pair_constr.py sm_gc_20_pf.lp SLSQP "edge(1,2)" "edge(1,3)" "edge(2,5)" "edge(2,6)" "edge(3,4)" "edge(4,5)" "edge(5,6)" "edge(9,18)" "edge(12,13)" "edge(17,18)" "edge(8,12)" "edge(4,13)" "edge(4,16)" "edge(8,18)" "edge(4,15)" "edge(12,14)" "edge(6,20)" "edge(6,12)" "edge(13,16)" "edge(15,20)" "edge(2,10)" "edge(11,12)"

echo "Ended at: " 
date
