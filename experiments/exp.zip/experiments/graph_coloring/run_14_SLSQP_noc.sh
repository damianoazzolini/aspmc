#!/bin/bash
#SBATCH --job-name=coloring_14_noc_s
#SBATCH --ntasks=1
#SBATCH --mem=16gb
#SBATCH --partition=longrun
#SBATCH --output=sm_14_no_constr_s.log

echo "Started at: " 
date

echo "Instance 14"
time python runner_without_pair_constr.py sm_gc_14_pf.lp SLSQP "edge(1,2)" "edge(1,3)" "edge(2,5)" "edge(2,6)" "edge(3,4)" "edge(4,5)" "edge(5,6)" "edge(1,5)" "edge(5,10)" "edge(9,10)" "edge(7,13)" "edge(10,11)" "edge(3,5)" "edge(1,10)" "edge(5,8)" "edge(6,7)"

echo "Ended at: " 
date
