#!/bin/bash
#SBATCH --job-name=coloring_10_s
#SBATCH --ntasks=1
#SBATCH --mem=16gb
#SBATCH --partition=longrun
#SBATCH --output=sm_10_s.log

echo "Started at: " 
date

echo "Instance 10"
time python runner_with_pair_constr.py sm_gc_10_pf.lp SLSQP "edge(1,2)" "edge(1,3)" "edge(2,5)" "edge(2,6)" "edge(3,4)" "edge(4,5)" "edge(5,6)" "edge(2,9)" "edge(5,7)" "edge(5,10)" "edge(5,9)" "edge(4,7)"

echo "Ended at: " 
date
