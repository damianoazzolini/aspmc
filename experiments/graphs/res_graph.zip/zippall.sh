python results_formatter.py
sleep 1
echo "Zipping"
zip res_graph.zip *.cleaned